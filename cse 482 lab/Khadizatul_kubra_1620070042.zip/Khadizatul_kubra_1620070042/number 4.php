<?php 

function power($number, $degree){
    for($x = 1; $x <= $number; $x++ ){
        return $c = $number * $degree;
    }   
}
echo multiply(2,4);

?>